#!/bin/bash
export GMX_MAXCONSTRWARN=-1
name=PEG200_200_PEG400_0_PEG600_0_PEG1000_0_ACN_8690_HEX_3479
#minimization_soft-coring
#mkdir minimization
#cd minimization
#gmx_mpi grompp -p ../topol.top -c ../struc/PEG200_0_PEG400_0_PEG600_200_PEG1000_0_W_DCE_16160.gro -f ../mdp_files/em.mdp  -o em.tpr -maxwarn 2
#gmx_mpi mdrun -v -s em.tpr -deffnm "$name"_em -rdd 1.4
#cd ..

#equilibration_nvt dt=0.01
#mkdir  equilibration_nvt
#cd equilibration_nvt
#gmx_mpi grompp -p ../topol.top -c ../minimization_2/"$name"_em2.gro -f ../mdp_files/nvt.mdp -n ../ndx/index.ndx -r ../minimization_2/"$name"_em2.gro -o nvt.tpr -maxwarn 2
#gmx_mpi mdrun -v -s nvt.tpr -deffnm "$name"_nvt
#cd ..

#equilibration_nvt dt=0.02
#mkdir  equilibration_nvt_2
#cd equilibration_nvt_2
#gmx_mpi grompp -p ../topol.top -c ../equilibration_nvt/"$name"_nvt.gro -f ../mdp_files/nvt2.mdp -n ../ndx/index.ndx -r ../equilibration_nvt/"$name"_nvt.gro -o nvt2.tpr -maxwarn 2
#gmx_mpi mdrun -v -s nvt2.tpr -deffnm "$name"_nvt2
#cd ..


#equilibration_nvt dt=0.05
#mkdir  equilibration_nvt_3
#cd equilibration_nvt_3
#gmx_mpi grompp -p ../topol.top -c ../equilibration_nvt_2/"$name"_nvt2.gro -f ../mdp_files/nvt3.mdp -n ../ndx/index.ndx -r ../equilibration_nvt_2/"$name"_nvt2.gro -o nvt3.tpr -maxwarn 2
#gmx_mpi mdrun -v -s nvt3.tpr -deffnm "$name"_nvt3
#cd ..

#equilibration_nvt dt=0.1
#mkdir  equilibration_nvt_4
#cd equilibration_nvt_4
#gmx_mpi grompp -p ../topol.top -c ../equilibration_nvt_3/"$name"_nvt3.gro -f ../mdp_files/nvt4.mdp -n ../ndx/index.ndx -r ../equilibration_nvt_3/"$name"_nvt3.gro -o nvt4.tpr -maxwarn 2
#gmx_mpi mdrun -v -s nvt4.tpr -deffnm "$name"_nvt4
#cd ..

#equilibration_nvt dt=0.15
#mkdir  equilibration_nvt_5
#cd equilibration_nvt_5
#gmx_mpi grompp -p ../topol.top -c ../equilibration_nvt_4/"$name"_nvt4.gro -f ../mdp_files/nvt5.mdp -n ../ndx/index.ndx -r ../equilibration_nvt_4/"$name"_nvt4.gro -o nvt5.tpr -maxwarn 2
#gmx_mpi mdrun -v -s nvt5.tpr -deffnm "$name"_nvt5
#cd ..

#equilibration_npt 400bar 
#mkdir equilibration_npt_400bar
#cd equilibration_npt_400bar
#gmx_mpi grompp -p ../topol.top -c ../equilibration_nvt_5/"$name"_nvt5.gro -f ../mdp_files/npt_400bar.mdp -n ../ndx/index.ndx -r ../equilibration_nvt_5/"$name"_nvt5.gro -o npt_400bar.tpr -maxwarn 3
#gmx_mpi mdrun -v -s npt_400bar.tpr -deffnm "$name"_npt_400
#cd ..

#equilibration_npt 1bar
#mkdir equilibration_npt_1bar
#cd equilibration_npt_1bar
#gmx_mpi grompp -p ../topol.top -c ../equilibration_npt_400bar/"$name"_npt_400.gro -f ../mdp_files/npt_1bar.mdp -n ../ndx/index.ndx -r ../equilibration_npt_400bar/"$name"_npt_400.gro -o npt_1bar.tpr -maxwarn 3
#gmx_mpi mdrun -v -s npt_1bar.tpr -deffnm "$name"_npt_1
#cd ..

#equilibration_npt production run
#mkdir production_run
#cd production_run
#gmx_mpi grompp -p ../topol.top -c ../equilibration_npt_1bar/"$name"_npt_1.gro -f ../mdp_files/npt_production.mdp -n ../ndx/index.ndx -r ../equilibration_npt_1bar/"$name"_npt_1.gro -o npt_prod.tpr -maxwarn 1
#srun gmx_mpi mdrun -v -s npt_prod.tpr -deffnm "$name"_npt_prod
#cd ..

#cd production_run
#gmx_mpi mdrun -s npt_prod.tpr -cpi PEG200_200_PEG400_0_PEG600_0_PEG1000_0_ACN_8690_HEX_3479_npt_prod.cpt -deffnm "$name"_npt_prod -v
#cd ..

